import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from spm.server import create_app  # noqa: E402

app = create_app()
